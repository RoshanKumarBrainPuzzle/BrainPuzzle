# Brain Puzzle – Roshan Kumar

यह प्रोजेक्ट एक offline-first Hindi/English brain puzzle game है।

## फोल्डर
- `app/` – Android Studio Kotlin WebView wrapper और स्थानीय HTML game।
- `website/` – वेबसाइट/PWA संस्करण, manifest और service worker।
- `store-materials/` – Play Store listing और privacy policy के draft।

## फीचर
- 30 प्रश्न: Logic, Math, Patterns और Brain Teasers।
- Hindi/English प्रश्न, विकल्प और explanations।
- Score, timer, hint, category selection और local device statistics।
- PWA offline cache (पहली सफल online visit/install के बाद)।

## Android build
Android Studio में इस folder को खोलें, Gradle sync करें और `app` का debug APK बनाकर अपने फोन पर टेस्ट करें। अभी signed release APK/AAB नहीं बनी है।

## सीमाएँ
Cloud sync, online leaderboard, multiplayer और AdMob अभी शामिल नहीं हैं। Privacy policy और store listing draft को वास्तविक release से पहले जाँचकर पूरा करना होगा।
