# Brain Puzzle – Roshan Kumar

यह शुरुआती Android Studio + वेबसाइट/PWA प्रोजेक्ट है। इसमें 30 ऑफलाइन पहेलियाँ, हिंदी/English प्रश्न और विकल्प, कैटेगरी, स्कोर, टाइमर, हिंट और डिवाइस पर सेव होने वाली प्रगति शामिल है।

## अभी क्या शामिल है
- Android WebView ऐप का सोर्स कोड
- वेबसाइट/PWA फाइलें और ऑफलाइन cache
- 30 सवाल हिंदी और English में
- हिंदी/English भाषा चयन याद रहता है
- स्कोर, हल किए गए सवाल और best score डिवाइस पर सेव होते हैं

## अभी क्या शामिल नहीं है
- तैयार APK या signed AAB फाइल नहीं बनी है
- Firebase/cloud sync, ऑनलाइन leaderboard, multiplayer और AdMob अभी नहीं जुड़े हैं
- Play Store पर प्रकाशित या Google द्वारा review नहीं हुआ है

## Android पर टेस्ट करने के लिए
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस पूरे प्रोजेक्ट फ़ोल्डर को Android Studio में Open करें।
3. Gradle sync पूरा होने दें; Android SDK Platform 36 इंस्टॉल करें।
4. Android फोन में Developer options और USB debugging चालू करके फोन जोड़ें।
5. Android Studio में Run दबाकर ऐप इंस्टॉल करें।
6. हिंदी/English, सभी कैटेगरी, सही/गलत जवाब, hint, timer, result और ऐप दोबारा खोलने पर saved progress जाँचें।

## वेबसाइट टेस्ट
`website` फ़ोल्डर को किसी static hosting पर publish करें। PWA/service worker के लिए HTTPS आवश्यक है (localhost पर भी टेस्ट हो सकता है)। पहले ऑनलाइन खोलें, फिर airplane mode में reload करके offline व्यवहार जाँचें।

## महत्वपूर्ण
पहली बार Play Store पर डालने से पहले package ID, privacy policy, Data safety, app icon, screenshots, content rating और सभी Play policies की जाँच जरूरी है। विज्ञापन या analytics जोड़ने से पहले privacy policy update करें।


## Version 3.1 सुधार
- Brain Teasers श्रेणी में 5 पहेलियाँ अलग की गईं; अब चारों श्रेणियों में प्रश्न उपलब्ध हैं।
- भाषा बदलने पर HTML भाषा टैग भी अपडेट होता है।
- वेबसाइट Service Worker cache version अपडेट किया गया ताकि नए बदलाव पुराने cache से न दबें।
