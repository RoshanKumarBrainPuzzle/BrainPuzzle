plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.roshankumar.brainpuzzle"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.roshankumar.brainpuzzle"
        minSdk = 23
        targetSdk = 36
        versionCode = 2
        versionName = "1.0.1"
    }
}
